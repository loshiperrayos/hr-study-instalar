import { initializeApp } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-app.js";
import {
  getAuth, GoogleAuthProvider, signInWithPopup, createUserWithEmailAndPassword,
  signInWithEmailAndPassword, onAuthStateChanged, signOut, updateProfile
} from "https://www.gstatic.com/firebasejs/11.6.1/firebase-auth.js";
import {
  getFirestore, doc, getDoc, setDoc, collection, addDoc, getDocs,
  query, where, orderBy, serverTimestamp, onSnapshot, limit
} from "https://www.gstatic.com/firebasejs/11.6.1/firebase-firestore.js";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.4";

// Configuración del proyecto Firebase HR Study
const firebaseConfig = {
  apiKey: "AIzaSyCylEmC94YJD53PwDs-3LCsk9_hZXWlRN0",
  authDomain: "hr-study-yt.firebaseapp.com",
  projectId: "hr-study-yt",
  storageBucket: "hr-study-yt.firebasestorage.app",
  messagingSenderId: "789271443447",
  appId: "1:789271443447:web:f15a01f2cce9e6274020f2",
  measurementId: "G-T80LPWEMXZ"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
const googleProvider = new GoogleAuthProvider();

// Supabase Storage: Firebase sigue gestionando las cuentas.
const SUPABASE_URL = "https://srulczqcpjkgddqfhnmm.supabase.co";
const SUPABASE_PUBLISHABLE_KEY = "sb_publishable_TIBmCfSunQ5XVvSTJEQxnw_lFfv6oYH";
const STORAGE_BUCKET = "hr-study-files";
const supabase = createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
  accessToken: async () => currentUser ? await currentUser.getIdToken() : null,
  auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false }
});
let unsubscribeChat = null;

let currentUser = null;
let currentProfile = null;
let authMode = "login";
let currentView = "dashboard";
let selectedCourse = null;
let localTasks = JSON.parse(localStorage.getItem("hr-study-tasks-v2") || "[]");
const localStore = {
  subjects: JSON.parse(localStorage.getItem("hr-study-subjects-v2") || "[]"),
  exams: JSON.parse(localStorage.getItem("hr-study-exams-v2") || "[]"),
  schedule: JSON.parse(localStorage.getItem("hr-study-schedule-v2") || "[]"),
  notes: JSON.parse(localStorage.getItem("hr-study-notes-v2") || "[]")
};
function saveLocal(key) { localStorage.setItem(`hr-study-${key}-v2`, JSON.stringify(localStore[key])); }
let modalHandler = null;

const $ = id => document.getElementById(id);
const esc = value => String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function toast(message) {
  const el = $("toast"); el.textContent = message; el.classList.add("show");
  clearTimeout(toast.timer); toast.timer = setTimeout(() => el.classList.remove("show"), 2600);
}
function authMessage(message, isError = true) {
  const el = $("authMessage"); el.textContent = message; el.classList.remove("hidden");
  el.classList.toggle("error", isError);
}
function friendlyError(error) {
  const map = {
    "auth/invalid-credential":"Correo o contraseña incorrectos.",
    "auth/email-already-in-use":"Ese correo ya tiene una cuenta.",
    "auth/weak-password":"La contraseña debe tener al menos 6 caracteres.",
    "auth/popup-closed-by-user":"Se cerró la ventana de Google antes de terminar.",
    "auth/unauthorized-domain":"Este dominio no está autorizado en Firebase Authentication.",
    "auth/network-request-failed":"No se pudo conectar. Revisa tu internet."
  };
  return map[error.code] || error.message || "Ocurrió un error. Inténtalo nuevamente.";
}
function setAuthMode(mode) {
  authMode = mode;
  $("authName").classList.toggle("hidden", mode !== "register");
  $("authName").required = mode === "register";
  $("emailSubmit").textContent = mode === "register" ? "Crear cuenta" : "Iniciar sesión";
  $("modeButton").textContent = mode === "register" ? "¿Ya tienes cuenta? Iniciar sesión" : "¿No tienes cuenta? Crear cuenta";
  $("authMessage").classList.add("hidden");
}
$("modeButton").addEventListener("click", () => setAuthMode(authMode === "login" ? "register" : "login"));

async function ensureUserProfile(user) {
  const ref = doc(db, "users", user.uid);
  const snap = await getDoc(ref);
  if (!snap.exists()) {
    await setDoc(ref, {
      role: "student",
      email: user.email || "",
      displayName: user.displayName || "Estudiante",
      createdAt: serverTimestamp()
    });
    return { role: "student", email: user.email || "", displayName: user.displayName || "Estudiante" };
  }
  return snap.data();
}
$("authForm").addEventListener("submit", async e => {
  e.preventDefault();
  $("emailSubmit").disabled = true;
  try {
    const email = $("authEmail").value.trim();
    const password = $("authPassword").value;
    if (authMode === "register") {
      const name = $("authName").value.trim();
      const result = await createUserWithEmailAndPassword(auth, email, password);
      await updateProfile(result.user, { displayName: name });
      await ensureUserProfile(result.user);
    } else {
      await signInWithEmailAndPassword(auth, email, password);
    }
  } catch (error) { authMessage(friendlyError(error)); }
  finally { $("emailSubmit").disabled = false; }
});
$("googleButton").addEventListener("click", async () => {
  try {
    const result = await signInWithPopup(auth, googleProvider);
    await ensureUserProfile(result.user);
  } catch (error) { authMessage(friendlyError(error)); }
});
$("logoutButton").addEventListener("click", () => signOut(auth));

onAuthStateChanged(auth, async user => {
  currentUser = user;
  if (!user) {
    $("authScreen").classList.remove("hidden");
    $("appShell").classList.add("hidden");
    return;
  }
  try {
    currentProfile = await ensureUserProfile(user);
    $("authScreen").classList.add("hidden");
    $("appShell").classList.remove("hidden");
    $("userLabel").textContent = `${currentProfile.displayName || user.email} · ${currentProfile.role === "admin" ? "Administrador" : "Estudiante"}`;
    document.querySelectorAll(".admin-only").forEach(el => el.classList.toggle("hidden", currentProfile.role !== "admin"));
    currentView = "dashboard";
    await render();
  } catch (error) {
    toast("No se pudo cargar tu perfil: " + friendlyError(error));
  }
});

function heading(title, subtitle, buttonText = "", action = "") {
  return `<div class="page-heading"><div><p class="eyebrow">HR STUDY</p><h1>${title}</h1><p>${subtitle}</p></div>${buttonText ? `<button class="button primary" data-action="${action}">＋ ${buttonText}</button>` : ""}</div>`;
}
function empty(title, text) {
  return `<div class="empty-state"><div class="empty-icon">✦</div><h3>${title}</h3><p>${text}</p></div>`;
}
function field(label, name, type = "text", required = true, placeholder = "") {
  return `<div class="field"><label for="f-${name}">${label}</label><input id="f-${name}" name="${name}" type="${type}" ${required ? "required" : ""} placeholder="${esc(placeholder)}"></div>`;
}
function openModal(title, fields, handler) {
  $("modalTitle").textContent = title;
  $("modalFields").innerHTML = fields;
  modalHandler = handler;
  $("modalBackdrop").classList.remove("hidden");
}
function closeModal() { $("modalBackdrop").classList.add("hidden"); modalHandler = null; }
$("closeModal").onclick = closeModal;
$("cancelModal").onclick = closeModal;
$("modalBackdrop").addEventListener("click", e => { if (e.target === $("modalBackdrop")) closeModal(); });
$("modalForm").addEventListener("submit", async e => {
  e.preventDefault();
  if (!modalHandler) return;
  const values = Object.fromEntries(new FormData(e.currentTarget).entries());
  const submit = e.currentTarget.querySelector('[type="submit"]');
  submit.disabled = true;
  try { await modalHandler(values); closeModal(); await render(); }
  catch (error) { toast(friendlyError(error)); }
  finally { submit.disabled = false; }
});

async function getMyCourses() {
  const q = query(collection(db, "users", currentUser.uid, "enrollments"));
  const memberships = await getDocs(q);
  const courses = [];
  for (const membership of memberships.docs) {
    const courseSnap = await getDoc(doc(db, "courses", membership.id));
    if (courseSnap.exists()) courses.push({ id: courseSnap.id, ...courseSnap.data() });
  }
  return courses;
}
async function dashboardView() {
  const courses = currentProfile.role === "admin"
    ? (await getDocs(query(collection(db, "courses"), orderBy("createdAt", "desc")))).docs.map(d => ({id:d.id,...d.data()}))
    : await getMyCourses();
  return `${heading(`¡Hola, ${esc(currentProfile.displayName || "Estudiante")}!`, "Este es tu espacio de aprendizaje.", currentProfile.role === "admin" ? "Crear curso" : "Unirme a un curso", currentProfile.role === "admin" ? "course" : "join")}
    <div class="stats-grid">
      <div class="stat-card"><div class="stat-top">Mis cursos</div><div class="stat-value">${courses.length}</div><div class="stat-caption">Cursos disponibles para ti</div></div>
      <div class="stat-card"><div class="stat-top">Mi cuenta</div><div class="stat-value">${currentProfile.role === "admin" ? "Admin" : "Alumno"}</div><div class="stat-caption">Rol de acceso</div></div>
    </div>
    <section class="panel"><div class="panel-head"><h2>${currentProfile.role === "admin" ? "Cursos creados" : "Mis cursos"}</h2><button class="text-link" data-view="courses">Ver cursos →</button></div>
    ${courses.length ? `<div class="course-grid">${courses.map(courseCard).join("")}</div>` : empty("Todavía no hay cursos", currentProfile.role === "admin" ? "Crea el primer curso para tus estudiantes." : "Únete con el código que te entregue tu profesor.")}</section>`;
}
function courseCard(c) {
  return `<article class="course-card"><div class="course-band"></div><div class="course-card-body"><span class="pill blue">${esc(c.level || "Curso")}</span><h3>${esc(c.name)}</h3><p>${esc(c.description || "Material y novedades del curso.")}</p><button class="button secondary small" data-course="${esc(c.id)}">Abrir curso</button></div></article>`;
}
async function coursesView() {
  const courses = currentProfile.role === "admin"
    ? (await getDocs(query(collection(db, "courses"), orderBy("createdAt", "desc")))).docs.map(d => ({id:d.id,...d.data()}))
    : await getMyCourses();
  return `${heading(currentProfile.role === "admin" ? "Todos los cursos" : "Mis cursos", currentProfile.role === "admin" ? "Administra los cursos de HR Study." : "Aquí aparecen los cursos a los que te has unido.", currentProfile.role === "admin" ? "Crear curso" : "Unirme con código", currentProfile.role === "admin" ? "course" : "join")}
  ${courses.length ? `<div class="course-grid">${courses.map(courseCard).join("")}</div>` : empty("No hay cursos todavía", currentProfile.role === "admin" ? "Crea tu primer curso." : "Pídele el código de inscripción a tu profesor.")}`;
}
async function courseDetail(id) {
  const snap = await getDoc(doc(db, "courses", id));
  if (!snap.exists()) { toast("No se encontró el curso."); return; }
  selectedCourse = {id:snap.id,...snap.data()};
  currentView = "courseDetail";
  await render();
}
async function courseDetailView() {
  if (!selectedCourse) return coursesView();
  const postsSnap = await getDocs(query(collection(db, "courses", selectedCourse.id, "posts"), orderBy("createdAt", "desc")));
  const posts = postsSnap.docs.map(d => ({id:d.id,...d.data()}));
  const codeSnap = currentProfile.role === "admin" ? await getDoc(doc(db, "courses", selectedCourse.id, "private", "join")) : null;
  return `<div class="page-heading"><div><p class="eyebrow">HR STUDY / CURSO</p><h1>${esc(selectedCourse.name)}</h1><p>${esc(selectedCourse.description || "")}</p></div><button class="button secondary" data-view="courses">← Volver</button></div>
    ${codeSnap?.exists() ? `<div class="notice"><strong>Código de inscripción:</strong> <span class="join-code">${esc(codeSnap.data().code)}</span> <button class="text-link" data-copy="${esc(codeSnap.data().code)}">Copiar</button></div>` : ""}
    ${currentProfile.role === "admin" ? `<div class="page-heading compact"><div><h2>Publicaciones</h2><p>Comparte avisos, tareas y materiales.</p></div><button class="button primary" data-action="post">＋ Nueva publicación</button></div>` : `<h2>Publicaciones del profesor</h2>`}
    ${posts.length ? `<div class="post-list">${posts.map(p=>`<article class="panel post"><span class="pill blue">${esc(p.type || "Aviso")}</span><h3>${esc(p.title)}</h3><p>${esc(p.body).replace(/\n/g,"<br>")}</p>${p.fileUrl ? `<div class="attachment"><span>📎 ${esc(p.fileName || "Archivo adjunto")}</span><a class="button secondary small" href="${esc(p.fileUrl)}" target="_blank" rel="noopener noreferrer">Abrir / descargar</a><small>Enlace privado temporal (7 días)</small></div>` : ""}<small>${p.createdAt?.toDate ? p.createdAt.toDate().toLocaleString("es-CL") : "Publicado"}</small></article>`).join("")}</div>` : empty("Aún no hay publicaciones","Cuando el profesor publique algo, aparecerá aquí.")}
    <section class="panel chat-panel" id="courseChatPanel">
      <div class="panel-head"><div><h2>Chat del curso</h2><small class="muted">Conversación en tiempo real · máximo 500 caracteres</small></div><span class="pill green">Moderado</span></div>
      <div id="chatMessages" class="chat-messages"><p class="muted">Cargando mensajes…</p></div>
      <form id="chatForm" class="chat-form"><input id="chatInput" name="message" maxlength="500" autocomplete="off" placeholder="Escribe un mensaje respetuoso…" required><button class="button primary" type="submit">Enviar</button></form>
      <p class="chat-guidelines">Reglas: respeto, nada de insultos, spam, datos personales ni enlaces sospechosos. El filtro automático es básico y el profesor puede moderar el chat.</p>
    </section>`;
}

async function manageView() {
  if (currentProfile.role !== "admin") return empty("Acceso restringido", "Esta sección es solo para el administrador.");
  return `${heading("Administrar cursos","Crea cursos y comparte el código de inscripción.","Crear curso","course")}
  <div class="notice">La cuenta administradora es la única autorizada para crear cursos y publicar contenido.</div>`;
}
function localListView(key, title, subtitle, button, fields) {
  const items = localStore[key];
  const cards = items.map(item => `<article class="item-card"><div class="item-main"><h3>${esc(item.title || item.name || item.subject || item.day)}</h3><p>${esc(item.body || item.details || item.teacher || item.time || item.date || "")}</p></div><button class="text-link" data-local-delete="${key}" data-id="${item.id}">Eliminar</button></article>`).join("");
  return `${heading(title, subtitle, button, `local-${key}`)}${items.length ? `<div class="item-list">${cards}</div>` : empty(`Aún no hay ${title.toLowerCase()}`, `Agrega tu primer elemento para comenzar.`)}`;
}
function subjectsView() { return localListView("subjects","Mis materias","Organiza tus asignaturas.","Agregar materia"); }
function examsView() { return localListView("exams","Pruebas y evaluaciones","Recuerda las fechas importantes.","Agregar prueba"); }
function scheduleView() { return localListView("schedule","Mi horario","Consulta tus clases de la semana.","Agregar clase"); }
function notesView() { return localListView("notes","Mis apuntes","Guarda resúmenes y recordatorios.","Nuevo apunte"); }
function openLocalModal(key) {
  const configs = {
    subjects: ["Agregar materia", field("Nombre de la materia","name") + field("Profesor (opcional)","teacher","text",false)],
    exams: ["Agregar prueba", field("Nombre de la prueba","title") + field("Materia","subject","text",false) + field("Fecha","date","date",false) + field("Contenido","details","text",false)],
    schedule: ["Agregar clase", `<div class="field"><label for="f-day">Día</label><select id="f-day" name="day"><option>Lunes</option><option>Martes</option><option>Miércoles</option><option>Jueves</option><option>Viernes</option></select></div>` + field("Hora","time","time") + field("Materia","subject")],
    notes: ["Nuevo apunte", field("Título","title") + `<div class="field"><label for="f-body">Contenido</label><textarea id="f-body" name="body" required></textarea></div>`]
  };
  const [title, fields] = configs[key];
  openModal(title, fields, async values => {
    localStore[key].push({ ...values, id: crypto.randomUUID(), createdAt: new Date().toISOString() });
    saveLocal(key); toast("Guardado correctamente.");
  });
}
function tasksView() {
  return `${heading("Mis tareas","Estas tareas se guardan en este navegador.","Agregar tarea","task")}
  ${localTasks.length ? `<div class="panel list">${localTasks.map(t=>`<div class="task-row ${t.done?"task-done":""}"><input type="checkbox" data-task="${t.id}" ${t.done?"checked":""}><div class="task-info"><strong>${esc(t.title)}</strong><small>${esc(t.date || "Sin fecha")}</small></div><button class="text-link" data-delete-task="${t.id}">Eliminar</button></div>`).join("")}</div>` : empty("No tienes tareas guardadas","Agrega una tarea para organizarte.")}`;
}
async function render() {
  document.querySelectorAll(".nav-item").forEach(b => b.classList.toggle("active", b.dataset.view === currentView));
  $("pageName").textContent = ({dashboard:"Inicio",courses:"Mis cursos",tasks:"Mis tareas",subjects:"Materias",exams:"Pruebas",schedule:"Horario",notes:"Apuntes",manage:"Administrar cursos",courseDetail:"Curso"})[currentView] || "HR Study";
  $("sidebar").classList.remove("open");
  const views = {dashboard:dashboardView,courses:coursesView,tasks:tasksView,subjects:subjectsView,exams:examsView,schedule:scheduleView,notes:notesView,manage:manageView,courseDetail:courseDetailView};
  try {
    $("appContent").innerHTML = await (views[currentView] || dashboardView)();
    if (currentView === "courseDetail" && selectedCourse) setupCourseChat();
    else if (unsubscribeChat) { unsubscribeChat(); unsubscribeChat = null; }
  } catch (error) { $("appContent").innerHTML = `<div class="notice error">No se pudo cargar esta sección: ${esc(friendlyError(error))}</div>`; }
}
function openCourseModal() {
  openModal("Crear curso", field("Nombre del curso","name") + field("Nivel o curso","level", "text", true, "Ej. 8° básico") + field("Descripción","description","text",false), async v => {
    const ref = await addDoc(collection(db,"courses"), {name:v.name.trim(),level:v.level.trim(),description:v.description.trim(),createdAt:serverTimestamp(),createdBy:currentUser.uid});
    const code = makeCode();
    await setDoc(doc(db,"joinCodes",code), {courseId:ref.id,enabled:true,createdAt:serverTimestamp()});
    await setDoc(doc(db,"courses",ref.id,"private","join"), {code});
    toast("Curso creado. Código: " + code);
  });
}
function makeCode() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const bytes = crypto.getRandomValues(new Uint8Array(6));
  return Array.from(bytes, b => chars[b % chars.length]).join("");
}
function openJoinModal() {
  openModal("Unirme a un curso", field("Código de inscripción","code","text",true,"Ej. MAT8K92"), async v => {
    const code = v.code.trim().toUpperCase();
    const codeSnap = await getDoc(doc(db,"joinCodes",code));
    if (!codeSnap.exists() || codeSnap.data().enabled !== true) throw new Error("El código no existe o está desactivado.");
    const courseId = codeSnap.data().courseId;
    await setDoc(doc(db,"users",currentUser.uid,"enrollments",courseId), {courseId,joinCode:code,joinedAt:serverTimestamp()});
    toast("¡Te uniste al curso!");
  });
}
function openPostModal() {
  openModal("Nueva publicación", `<div class="field"><label for="f-type">Tipo</label><select id="f-type" name="type"><option>Aviso</option><option>Tarea</option><option>Material</option></select></div>` + field("Título","title") + `<div class="field"><label for="f-body">Contenido</label><textarea id="f-body" name="body" required maxlength="4000"></textarea></div><div class="field"><label for="f-file">Adjuntar archivo (opcional, máximo 20 MB)</label><input id="f-file" name="file" type="file" accept=".pdf,.doc,.docx,.ppt,.pptx,.xls,.xlsx,.png,.jpg,.jpeg,.webp,application/pdf,image/png,image/jpeg,image/webp"></div><p class="tiny muted">Los archivos se guardan en el bucket privado y se comparten mediante un enlace temporal de 7 días.</p>`, async v => {
    const file = v.file instanceof File && v.file.size > 0 ? v.file : null;
    let fileInfo = {};
    if (file) {
      const allowed = /\.(pdf|doc|docx|ppt|pptx|xls|xlsx|png|jpe?g|webp)$/i.test(file.name);
      if (!allowed) throw new Error("Tipo de archivo no permitido.");
      if (file.size > 20 * 1024 * 1024) throw new Error("El archivo supera el límite de 20 MB.");
      const safeName = file.name.normalize("NFKD").replace(/[^a-zA-Z0-9._-]/g, "_").slice(-90);
      const path = `${selectedCourse.id}/${crypto.randomUUID()}-${safeName}`;
      const { error: uploadError } = await supabase.storage.from(STORAGE_BUCKET).upload(path, file, { contentType: file.type || "application/octet-stream", upsert: false });
      if (uploadError) throw new Error("No se pudo subir el archivo: " + uploadError.message);
      const { data: signed, error: signedError } = await supabase.storage.from(STORAGE_BUCKET).createSignedUrl(path, 604800);
      if (signedError) throw new Error("El archivo se subió, pero no se pudo crear el enlace: " + signedError.message);
      fileInfo = { fileName: file.name, filePath: path, fileUrl: signed.signedUrl, fileExpiresAt: new Date(Date.now() + 604800000).toISOString() };
    }
    await addDoc(collection(db,"courses",selectedCourse.id,"posts"), {type:v.type,title:v.title.trim(),body:v.body.trim(),...fileInfo,createdAt:serverTimestamp(),createdBy:currentUser.uid});
    toast(file ? "Publicación y archivo compartidos." : "Publicación creada.");
  });
}

const blockedTerms = ["idiota", "imbecil", "estupido", "estupida", "mierda", "puta", "puto", "cabrón", "cabron", "pendejo", "pendeja", "maricon", "maricón", "perra", "zorra"];
function messageHasBlockedWords(message) {
  const normalized = message.toLocaleLowerCase("es").normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  const words = normalized.match(/[a-z0-9]+/g) || [];
  return blockedTerms.some(term => words.includes(term.normalize("NFD").replace(/[\u0300-\u036f]/g, "")));
}
function setupCourseChat() {
  if (unsubscribeChat) unsubscribeChat();
  const messagesEl = $("chatMessages");
  const messagesQuery = query(collection(db, "courses", selectedCourse.id, "messages"), orderBy("createdAt", "asc"), limit(100));
  unsubscribeChat = onSnapshot(messagesQuery, snapshot => {
    if (!messagesEl) return;
    if (snapshot.empty) { messagesEl.innerHTML = `<div class="chat-empty">Todavía no hay mensajes. ¡Saluda al curso!</div>`; return; }
    messagesEl.innerHTML = snapshot.docs.map(d => {
      const m = d.data();
      const mine = m.authorUid === currentUser.uid;
      const time = m.createdAt?.toDate ? m.createdAt.toDate().toLocaleTimeString("es-CL", {hour:"2-digit",minute:"2-digit"}) : "ahora";
      return `<article class="chat-message ${mine ? "mine" : ""}"><div class="chat-message-meta"><strong>${esc(m.authorName || "Estudiante")}</strong><time>${esc(time)}</time></div><p>${esc(m.text || "")}</p>${currentProfile.role === "admin" ? `<button class="text-link chat-delete" data-delete-message="${esc(d.id)}">Eliminar mensaje</button>` : ""}</article>`;
    }).join("");
    messagesEl.scrollTop = messagesEl.scrollHeight;
  }, error => { if (messagesEl) messagesEl.innerHTML = `<p class="notice error">No se pudo cargar el chat: ${esc(friendlyError(error))}</p>`; });
}
async function sendCourseMessage(form) {
  const input = $("chatInput");
  const text = input.value.trim().replace(/\s+/g, " ");
  if (!text) return;
  if (text.length > 500) { toast("El mensaje supera los 500 caracteres."); return; }
  if (messageHasBlockedWords(text)) { toast("Ese mensaje contiene vocabulario no permitido. Escríbelo de otra manera."); return; }
  const button = form.querySelector("button[type=submit]");
  button.disabled = true;
  try {
    await addDoc(collection(db, "courses", selectedCourse.id, "messages"), { text, authorUid: currentUser.uid, authorName: currentProfile.displayName || currentUser.email || "Estudiante", createdAt: serverTimestamp() });
    input.value = "";
  } catch (error) { toast("No se pudo enviar: " + friendlyError(error)); }
  finally { button.disabled = false; }
}

function openTaskModal() {
  openModal("Agregar tarea",field("Nombre de la tarea","title") + field("Fecha (opcional)","date","date",false), async v => {
    localTasks.push({id:crypto.randomUUID(),title:v.title.trim(),date:v.date,done:false});
    localStorage.setItem("hr-study-tasks-v2",JSON.stringify(localTasks));
    toast("Tarea guardada.");
  });
}
document.addEventListener("click", async e => {
  const nav = e.target.closest("[data-view]");
  if (nav) { currentView = nav.dataset.view; selectedCourse = null; await render(); return; }
  const action = e.target.closest("[data-action]");
  if (action) {
    if (action.dataset.action === "course") openCourseModal();
    if (action.dataset.action === "join") openJoinModal();
    if (action.dataset.action === "post") openPostModal();
    if (action.dataset.action === "task") openTaskModal();
    if (action.dataset.action.startsWith("local-")) openLocalModal(action.dataset.action.slice(6));
    return;
  }
  const course = e.target.closest("[data-course]");
  if (course) { await courseDetail(course.dataset.course); return; }
  const copy = e.target.closest("[data-copy]");
  if (copy) { try { await navigator.clipboard.writeText(copy.dataset.copy); toast("Código copiado."); } catch { toast("No se pudo copiar automáticamente."); } return; }
  const deleteMessage = e.target.closest("[data-delete-message]");
  if (deleteMessage && currentProfile.role === "admin" && selectedCourse) {
    if (!confirm("¿Eliminar este mensaje del chat?")) return;
    try { await (await import("https://www.gstatic.com/firebasejs/11.6.1/firebase-firestore.js")).deleteDoc(doc(db, "courses", selectedCourse.id, "messages", deleteMessage.dataset.deleteMessage)); toast("Mensaje eliminado."); }
    catch (error) { toast(friendlyError(error)); }
    return;
  }
  const localDel = e.target.closest("[data-local-delete]");
  if (localDel) { const key=localDel.dataset.localDelete; localStore[key]=localStore[key].filter(x=>x.id!==localDel.dataset.id); saveLocal(key); await render(); return; }
  const del = e.target.closest("[data-delete-task]");
  if (del) { localTasks=localTasks.filter(t=>t.id!==del.dataset.deleteTask);localStorage.setItem("hr-study-tasks-v2",JSON.stringify(localTasks));await render();return; }
});
document.addEventListener("change", e => {
  if (e.target.matches("[data-task]")) {
    const task=localTasks.find(t=>t.id===e.target.dataset.task); if(task){task.done=e.target.checked;localStorage.setItem("hr-study-tasks-v2",JSON.stringify(localTasks));render();}
  }
});
document.addEventListener("submit", e => {
  if (e.target.id === "chatForm") { e.preventDefault(); sendCourseMessage(e.target); }
});
$("menuButton").addEventListener("click", () => $("sidebar").classList.toggle("open"));
setAuthMode("login");
if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
  window.addEventListener("load", () => navigator.serviceWorker.register("./sw.js").catch(() => {}));
}
