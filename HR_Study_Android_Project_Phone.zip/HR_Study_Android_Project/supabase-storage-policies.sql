-- HR Study: permisos del bucket privado hr-study-files.
-- Solo la cuenta administradora de Firebase puede subir, crear enlaces firmados y borrar objetos.
-- La política valida el emisor, proyecto y UID del token Firebase.

DROP POLICY IF EXISTS "HR Study admin uploads course files" ON storage.objects;
DROP POLICY IF EXISTS "HR Study admin signs course files" ON storage.objects;
DROP POLICY IF EXISTS "HR Study admin deletes course files" ON storage.objects;

CREATE POLICY "HR Study admin uploads course files"
ON storage.objects FOR INSERT TO public
WITH CHECK (
  bucket_id = 'hr-study-files'
  AND (auth.jwt() ->> 'iss') = 'https://securetoken.google.com/hr-study-yt'
  AND (auth.jwt() ->> 'aud') = 'hr-study-yt'
  AND (auth.jwt() ->> 'sub') = 'eoT99VH0JlVfqKfkH6r001IQqk83'
);

CREATE POLICY "HR Study admin signs course files"
ON storage.objects FOR SELECT TO public
USING (
  bucket_id = 'hr-study-files'
  AND (auth.jwt() ->> 'iss') = 'https://securetoken.google.com/hr-study-yt'
  AND (auth.jwt() ->> 'aud') = 'hr-study-yt'
  AND (auth.jwt() ->> 'sub') = 'eoT99VH0JlVfqKfkH6r001IQqk83'
);

CREATE POLICY "HR Study admin deletes course files"
ON storage.objects FOR DELETE TO public
USING (
  bucket_id = 'hr-study-files'
  AND (auth.jwt() ->> 'iss') = 'https://securetoken.google.com/hr-study-yt'
  AND (auth.jwt() ->> 'aud') = 'hr-study-yt'
  AND (auth.jwt() ->> 'sub') = 'eoT99VH0JlVfqKfkH6r001IQqk83'
);
