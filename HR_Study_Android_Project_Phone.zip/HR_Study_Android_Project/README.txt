HR STUDY 3.0

NUEVO EN ESTA VERSION
- Adjuntar PDF, Word, PowerPoint, Excel e imágenes en publicaciones del profesor.
- Archivos en bucket privado de Supabase Storage (máximo 20 MB por archivo en la aplicación).
- Enlaces firmados temporales para descargar archivos (caducan en 7 días).
- Chat por curso en tiempo real con Firestore.
- Filtro básico de vocabulario en el navegador, máximo 500 caracteres y eliminación de mensajes por el administrador.
- Interfaz adaptada a celulares y computadoras.

ANTES DE PUBLICAR
1. En Firebase Authentication, confirma Google y Correo/contraseña habilitados y el dominio Netlify autorizado.
2. En Firestore > Rules, publica el archivo firestore.rules incluido.
3. Comprueba que users/eoT99VH0JlVfqKfkH6r001IQqk83 exista con role = admin.
4. En Supabase > Authentication > Third-Party Auth, confirma que Firebase esté conectado con Project ID hr-study-yt.
5. En Supabase > SQL Editor, ejecuta TODO el archivo supabase-storage-policies.sql.
6. En Supabase > Storage > hr-study-files, comprueba que el bucket siga siendo PRIVADO.
7. En Supabase > Storage > Configuration, establece el límite de tamaño de archivo en 20 MB si el panel lo permite. Los tipos permitidos deben incluir PDF, DOC, DOCX, PPT, PPTX, XLS, XLSX, PNG, JPG y WEBP.

PUBLICAR EN NETLIFY DESDE CELULAR
1. Descarga y extrae HR_Study_v3.zip en tu dispositivo.
2. Abre https://app.netlify.com/drop e inicia sesión.
3. Sube la carpeta HR_Study completa (la que contiene index.html, app.js y styles.css), no solo el ZIP ni un archivo suelto.
4. Si Netlify crea un sitio nuevo, usa el mismo dominio o actualiza el dominio autorizado en Firebase Authentication.
5. Abre el sitio y prueba iniciar sesión como administrador.

PRUEBAS
- Como administrador: abre un curso, crea una publicación con un PDF pequeño y comprueba que aparezca el enlace.
- Como estudiante inscrito: abre el mismo curso y prueba descargar el archivo.
- Envía mensajes desde dos cuentas para comprobar el chat en tiempo real.
- Comprueba que el administrador puede eliminar mensajes.

SEGURIDAD Y LIMITACIONES
- La cuenta administradora está fijada por UID en app.js, firestore.rules y supabase-storage-policies.sql.
- Los archivos están en un bucket privado. La aplicación solo permite al administrador subirlos y genera enlaces firmados temporales de 7 días. Quien reciba o reenvíe el enlace puede abrirlo hasta que caduque.
- El filtro de vocabulario se ejecuta en el navegador y puede ser evadido; Firestore sí limita quién puede leer/escribir en el chat y limita los mensajes a 500 caracteres. Para moderación imposible de evadir se necesitaría validación en servidor.
- El límite de 20 MB también debe coincidir con la configuración del bucket.
- Supabase Free y Firebase tienen cuotas y límites; no son servicios ilimitados.
- Las tareas personales, materias, pruebas, horario y apuntes siguen guardándose localmente en cada navegador.

IMPORTANTE
Nunca publiques una clave secreta de Supabase ni una clave service_role. La clave sb_publishable incluida es pública y está protegida por las políticas RLS.
